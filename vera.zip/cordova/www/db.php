<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id8944056_veralaras","vera12345","id8944056_vera") or die ("could not connect database");
?>